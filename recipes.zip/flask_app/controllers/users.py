from flask import render_template, request, redirect, session
from flask_app import app
from flask_app.models.user import User
from flask import flash

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["POST"])
def register():
    valid_user = User.create_user(request.form)

    if not valid_user:
        return redirect("/")
    
    session["user_id"] = valid_user.id
    
    return redirect("/recipes/home")

@app.route("/login", methods=["POST"])
def login():
    valid_user = User.authenticate_user_input(request.form)
    if not valid_user:
        return redirect("/")

    session["user_id"] = valid_user.id
    return redirect("/recipes/home")


#clear session via logout
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

