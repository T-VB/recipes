from flask import render_template, session,redirect, request
from flask_app import app
from flask import flash
from flask_app.models.user import User
from flask_app.models.recipe import Recipe

#Render GET methods
@app.route('/recipes/home')
def recipes():
    if 'user_id' not in session:
        flash('In order to access recipes you must be logged in')
        return redirect('/')
    recipe_id = {
        'id':session['user_id']
    }
    return render_template('recipes.html', all_recipes=Recipe.get_all(), user=User.get_one(session['user_id']))

@app.route('/recipes/<int:id>')
def show_recipe(id):

    data = {
        "id":id
    }
    return render_template('show_recipe.html', recipe=Recipe.get_one(data), user=User.get_one(session['user_id']))

@app.route("/recipe/create")
def recipe_create():
    return render_template("add_recipe.html")

@app.route('/recipes/edit/<int:id>')
def edit_recipe(id):
    data = {
        "id":id
    }
    return render_template("edit_recipe.html", recipe=Recipe.get_one(data))


#Render Post/Action methods
@app.route('/recipes', methods=['POST'])
def create_recipe():
    if not Recipe.validate_recipe(request.form):
        return redirect('/recipe/create')
    #if the recipe is valid after going through method, return that users recipe page
    Recipe.create_recipe(request.form)
    return redirect('/recipes/home')

@app.route('/recipes/<int:id>', methods=['POST'])
def update_recipe(id):
    if not Recipe.validate_recipe(request.form):
        return redirect(f'/recipes/edit/{id}')
    Recipe.update(request.form) 
    return redirect('/recipes/home')

#delete specific recipes
@app.route('/recipes/delete/<int:id>')
def delete_recipe(id):
    Recipe.delete_one(id)
    return redirect('/recipes/home')