from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_bcrypt import Bcrypt
from flask_app.models import user
import re
from datetime import datetime
import math

class Recipe:
    db_name = 'dojo_recipes'
    def __init__(self,db_data):
        self.id = db_data['id']
        self.name = db_data['name']
        self.date_made = db_data['date_made']
        self.description = db_data['description']
        self.time = db_data['time']
        self.created_at = db_data['created_at']
        self.updated_at = db_data['updated_at']
        self.user_id = db_data['user_id']
        self.creator = None

    def time_span(self):
        now = datetime.now()
        delta = now - self.created_at
        print(delta.days)
        print(delta.total_seconds())
        #if message (message.timespan in jinja) was created days ago, hours, min ago, sec ago
        if delta.days > 0:
            return f"{delta.days} days ago"
        elif (math.floor(delta.total_seconds() / 60)) >= 60:
            return f"{math.floor(math.floor(delta.total_seconds() / 60)/60)} hours ago"
        elif delta.total_seconds() >= 60:
            return f"{math.floor(delta.total_seconds() / 60)} minutes ago"
        else:
            return f"{math.floor(delta.total_seconds())} seconds ago"
    
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM recipes JOIN users on recipes.user_id = users.id;"
        results = connectToMySQL(cls.db_name).query_db(query)
        recipes = []
        for recipe in results:
            recipe_object = cls(recipe)
            recipe_object.creator = user.User(
                {
                    "id":recipe['users.id'],
                    "first_name":recipe['first_name'],
                    "last_name":recipe['last_name'],
                    "email":recipe['email'],
                    "password":recipe['password'],
                    "created_at":recipe['users.created_at'],
                    "updated_at":recipe['users.updated_at']
                }
            )
            recipes.append(recipe_object)
            print(recipes, f' this is working')
        return recipes

    @classmethod
    def create_recipe(cls,recipe_dict):
        if not cls.validate_recipe(recipe_dict):
            return False
        query = "INSERT INTO recipes (name,date_made,description,time,user_id) VALUES (%(name)s,%(date_made)s,%(description)s,%(time)s,%(user_id)s);"
        recipe_id = connectToMySQL(cls.db_name).query_db(query,recipe_dict)
        recipe = cls.get_one(recipe_dict)
        print("RESULT", result)
        print("RECEIPE ID" , recipe_id)
        print("RECIPE ===>" ,recipe )
        return recipe

    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM recipes JOIN users on recipes.user_id = users.id WHERE recipes.id = %(id)s;"
        result = connectToMySQL(cls.db_name).query_db(query,data)
        recipe_object = cls(result[0])
        recipe_object.creator = user.User(
            {
                "id":result[0]['users.id'],
                "first_name":result[0]['first_name'],
                "last_name":result[0]['last_name'],
                "email":result[0]['email'],
                "password":result[0]['password'],
                "created_at":result[0]['users.created_at'],
                "updated_at":result[0]['users.updated_at']
            }
        )
        print(recipe_object, f'- created successfully')
        return recipe_object
        

    @classmethod
    def update(cls, data):#, session_id):

        # Authenticate User first
        '''
        recipe = cls.get_one(recipe_dict["id"])
        if recipe.creator.id != session_id:
            flash("You must be the creator to update this recipe.")
            return False

        # Validate the input
        if not cls.is_valid(recipe_dict):
            return False
            '''
        # Update the data in the database.
        query = """UPDATE recipes
                    SET name = %(name)s, date_made=%(date_made)s, description = %(description)s, time = %(time)s
                    WHERE id = %(id)s;"""
        result = connectToMySQL(cls.db_name).query_db(query,data)
        
        return result

    @staticmethod
    def validate_recipe(data):
        is_valid = True
        if len(data['name']) < 3:
            is_valid = False
            flash("Name must be at least 3 characters.")
        if len(data['description']) < 3:
            is_valid = False
            flash("description must be at least 3 characters.")
        if len(data['date_made']) <=0:
            is_valid = False
            flash("Date is required")
        if "time" not in data:
            is_valid = False
            flash("Does your recipe take less than 30 min?")

        return is_valid
        
    @classmethod
    def delete_one(cls,recipe_id):
        data = {
            'id':recipe_id
        }
        query = "DELETE FROM recipes WHERE id = %(id)s;"
        connectToMySQL(cls.db_name).query_db(query,data)
        return recipe_id
    