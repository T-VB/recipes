from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app.models import recipe
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')


class User:
    db_name = 'dojo_recipes'
    def __init__(self,user):
        self.id = user['id']
        self.first_name = user['first_name']
        self.last_name = user['last_name']
        self.email = user['email']
        self.password = user['password']
        self.created_at = user['created_at']
        self.updated_at = user['updated_at']

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM users;"
        results = connectToMySQL(cls.db_name).query_db(query)
        users = []
        for user in results:
            users.append(cls(user))
        return users

    @classmethod
    def get_one(cls,user_id):
        data = {
            'id':user_id
        }
        query = "SELECT * FROM users WHERE id = %(id)s;"
        results = connectToMySQL(cls.db_name).query_db(query,data)
        if len(results) < 1:
            return False
        return cls(results[0])

    @classmethod
    def get_by_email(cls,email):
        data = {
            'email':email
        }
        query = "SELECT * FROM users WHERE email = %(email)s;"
        results = connectToMySQL(cls.db_name).query_db(query,data)
        if len(results) < 1:
            return False
        return cls(results[0])

    @classmethod
    def authenticate_user_input(cls,user_input):
        is_valid = True
        #get by email compare user input to db
        current_user = cls.get_by_email(user_input['email'])
        password_is_valid = True
        #if not existing user-> false
        if not current_user:
            is_valid = False
        else:
            password_is_valid = bcrypt.check_password_hash(current_user.password, user_input['password'])
            if not password_is_valid:
                is_valid = False
        if not is_valid:
            flash('That email and password combination does not match our records')
            return False
        return current_user
    
    @classmethod
    def create_user(cls,user):
        # Validate user
        if not cls.validate_user(user):
            return False

        # Hash password
        pw_hash = bcrypt.generate_password_hash(user['password'])
        user = user.copy()
        user["password"] = pw_hash
        print("User after adding pw: ", user)

        # Insert user into DB
        query = """
                INSERT into users (first_name, last_name, email, password)
                VALUES (%(first_name)s, %(last_name)s, %(email)s, %(password)s);"""

        new_user_id = connectToMySQL(User.db_name).query_db(query, user)
        new_user = cls.get_one(new_user_id)

        return new_user

    #retreive all messages logged-in user has received, and add to list: messages []
    @classmethod
    def get_user_recipes(cls,data):
        #for a one to many, 
        #left join user
        query = "SELECT * FROM users JOIN recipes ON users.id = recipes.user_id WHERE users.id = %(id)s;"
        results = connectToMySQL(cls.db_name).query_db(query,data)
        recipes = []
        for recipe in results:
            recipe_object = cls(recipe)
            recipe_object.user = user.User(
                {
                    "id":recipe('user_id'),
                    "first_name":recipe('first_name'),
                    "last_name":recipe('last_name'),
                    "email":recipe('email'),
                    "created_at":recipe('created_at'),
                    "updated_at":recipe('updated_at')
                }
            )
            recipes.append( cls(recipe) )
            print(recipes, f'working')
        return recipes

    @classmethod
    def validate_user(cls, user):
        is_valid = True
        #validate email doesn't already exist
        if len(user['email']) >=1:
            valid = False
            flash('That email already exists)')
        if len(user["first_name"]) < 3:
            valid = False
            flash("First name must be at least 3 characters.")
        if len(user["last_name"]) < 3:
            valid = False
            flash("Last name must be at least 3 characters.")
            #validate email formating 
        if not EMAIL_REGEX.match(user['email']): 
            flash("Invalid email address!")
            valid = False
        #validate passwords user input for password must match db
        if not user["password"] == user["password_confirmation"]:
            flash("Passwords must match.")
            valid = False


        #email_already_has_account = User.get_by_email(user["email"])
        #if email_already_has_account:
        #    flash("An account with that email already exists, please log in.")
        #    valid = False

        return is_valid